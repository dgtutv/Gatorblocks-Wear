package app.DTodd.gatorblocks;

public class dayOff {
    public static int[] dayOff={263, 287, 298, 312, 315, 329, 357, 358, 359, 360, 361, 364, 365, 1, 2, 3, 45, 48, 55, 76, 77, 78, 79, 80, 83, 84, 85, 86, 87, 101, 104, 136, 139}; //Put all days off here in day of year format, DO NOT INCLUDE WEEKENDS
}
